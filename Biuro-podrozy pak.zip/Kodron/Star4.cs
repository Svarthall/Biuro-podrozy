﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biuro_podrozy
{
    class Star4
    {
        public Wycieczka[] listW = new Wycieczka[5];

        public Star4()
        {
            Wycieczka W1 = new Wycieczka("Meksyk", "Cancun Bay Resort", 8200);
            listW[0] = W1;

            Wycieczka W2 = new Wycieczka("Hiszpania", "Playa Real Resort", 6000);
            listW[1] = W2;

            Wycieczka W3 = new Wycieczka("Egipt", "Continental Hurghada", 6800);
            listW[2] = W3;

            Wycieczka W4 = new Wycieczka("Grecja", "Lida Corfu", 5300);
            listW[3] = W4;

            Wycieczka W5 = new Wycieczka("Tajlandia", "Novotel Rayong", 7300);
            listW[4] = W5;
        }

        public Wycieczka getWycieczka(int A)
        {
            return listW[A];
        }
    }
}
