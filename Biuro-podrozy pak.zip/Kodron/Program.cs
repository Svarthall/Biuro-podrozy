﻿using System;

namespace Biuro_podrozy
{
    class Program
    {
        public Star3 wycieczki1 = new Star3();
        public Star4 wycieczki2 = new Star4();
        public Star5 wycieczki3 = new Star5();
        static void Main(string[] Args)
        {
            Program prog = new Program();
            prog.Test1();
        }

        public void Test1()
        {
            Random rnd = new Random();
            int randomA = rnd.Next(0, 4);
            int randomB = rnd.Next(0, 4);
            int randomC = rnd.Next(0, 4);

            Wycieczka chosenA = wycieczki1.getWycieczka(randomA);
            Wycieczka chosenB = wycieczki2.getWycieczka(randomB);
            Wycieczka chosenC = wycieczki3.getWycieczka(randomC);

            Wycieczka[] chosenList = new Wycieczka[4];
            chosenList[1] = chosenA;
            chosenList[2] = chosenB;
            chosenList[3] = chosenC;

            Console.WriteLine("Zbiór promowanych wycieczek");
            Console.WriteLine();
            Console.WriteLine("********************");
            Console.WriteLine("Numer: 1");
            Console.WriteLine("Kraj: " + chosenA.getKraj());
            Console.WriteLine("Termin: 6/15/2022 - 6/22/2022 (7dni)");
            Console.WriteLine("Hotel: " + chosenA.getHotel());
            Console.WriteLine("Wyżywienie: śniadania");
            Console.WriteLine("Cena: " + chosenA.getCena() + " PLN/os");
            Console.WriteLine("********************");
            Console.WriteLine();
            Console.WriteLine("Numer: 2");
            Console.WriteLine("Kraj: " + chosenB.getKraj());
            Console.WriteLine("Termin: 6/15/2022 - 6/25/2022 (10dni)");
            Console.WriteLine("Hotel: " + chosenB.getHotel());
            Console.WriteLine("Wyżywienie: All Inclusive");
            Console.WriteLine("Cena: " + chosenB.getCena() + " PLN/os");
            Console.WriteLine("********************");
            Console.WriteLine("Numer: 3");
            Console.WriteLine("Kraj: " + chosenC.getKraj());
            Console.WriteLine("Termin: 6/16/2022 - 6/29/2022 (14dni)");
            Console.WriteLine("Hotel: " + chosenC.getHotel());
            Console.WriteLine("Wyżywienie: All Inclusive");
            Console.WriteLine("Cena: " + chosenC.getCena() + "PLN/os");
            Console.WriteLine("********************");
            
            Console.WriteLine();
            Console.Write("Proszę podać NUMER wybranej oferty: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Wycieczka userChosen = chosenList[num1];
            int cenaW = userChosen.getCena();
            
            Console.Clear();
            Console.Write("Podaj liczbę osób dorosłych: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.Write("Podaj liczbę dzieci: ");
            int num3 = Convert.ToInt32(Console.ReadLine());
            Console.Clear();

            int ostatecznaCena = ((cenaW * num2) + (cenaW * num3 / 2));

            Console.WriteLine("Ostateczna cena: " + ostatecznaCena);

            Console.ReadLine();
        }
    }
}