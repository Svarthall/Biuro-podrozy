﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biuro_podrozy
{
    class Wycieczka
    {
        public string kraj;
        public string hotel;
        public int cenazapobyt;

        public Wycieczka(string kraj, string hotel, int cenazapobyt)
        {
            this.kraj = kraj;
            this.hotel = hotel;
            this.cenazapobyt = cenazapobyt;
        }

        public string getHotel()
        {
            return hotel;
        }
        public string getKraj()
        {
            return kraj;
        }

        public int getCena()
        {
            return cenazapobyt;
        }
    }
}
