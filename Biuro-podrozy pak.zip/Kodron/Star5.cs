﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biuro_podrozy
{
    class Star5
    {
        public Wycieczka[] listW = new Wycieczka[5];

        public Star5()
        {
            Wycieczka W1 = new Wycieczka("Meksyk", "Iberostar Quetzal", 13360);
            listW[0] = W1;

            Wycieczka W2 = new Wycieczka("Hiszpania", "Playacalida", 10600);
            listW[1] = W2;

            Wycieczka W3 = new Wycieczka("Egipt", "sharm Grand Plaza", 11380);
            listW[2] = W3;

            Wycieczka W4 = new Wycieczka("Grecja", "Labranda Sandy Beach Resort", 10320);
            listW[3] = W4;

            Wycieczka W5 = new Wycieczka("Tajlandia", "Mytt Beach Hotel", 13280);
            listW[4] = W5;
        }

        public Wycieczka getWycieczka(int A)
        {
            return listW[A];
        }
    }
}
